﻿using System;

namespace kalkulacka_s_cykly
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vítejte v kalkulačce");
            string pokracovani = "ano";

            while (pokracovani == "ano")
            {
                double vysledek = 0;
                Console.WriteLine("\nZvolte si operaci");
                Console.WriteLine("1 - sčítání");
                Console.WriteLine("2 - odčítání");
                Console.WriteLine("3 - násobení");
                Console.WriteLine("4 - dělení");
                int volba = Convert.ToInt16(Console.ReadLine());

                Console.WriteLine("\nZadejte první číslo:");
                double prvni_cislo = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("\nZadejte druhé číslo:");
                double druhe_cislo = Convert.ToDouble(Console.ReadLine());
            
                switch (volba)
                {
                    case 1:
                        vysledek = prvni_cislo + druhe_cislo;
                        break;

                    case 2:
                        vysledek = prvni_cislo - druhe_cislo;
                        break;

                    case 3:
                        vysledek = prvni_cislo * druhe_cislo;
                        break;

                    case 4:
                        vysledek = prvni_cislo / druhe_cislo;
                        break;
                }
                if ((volba > 0) && (volba < 5))
                    Console.WriteLine("\nVýsledek: {0}", vysledek);
                else
                    Console.WriteLine("\nNeplatná operace!");
                Console.WriteLine("\nPřejete si zadat další příklad? [ano/ne]");
                pokracovani = Console.ReadLine();
            }
            Console.WriteLine("\nZmáčkněte libovolnou klávesu a program se ukončí.");
            Console.ReadKey();
        }
    }
}
